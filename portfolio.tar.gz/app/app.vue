<template>
  <NuxtLoadingIndicator color="#ec7958" />
  <NuxtLayout><NuxtPage /></NuxtLayout>
</template>
